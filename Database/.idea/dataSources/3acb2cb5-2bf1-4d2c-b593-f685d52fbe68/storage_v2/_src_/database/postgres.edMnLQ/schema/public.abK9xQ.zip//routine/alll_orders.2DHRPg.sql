create function alll_orders() returns trigger
    language plpgsql
as
$$
BEGIN
        insert into all_orders(order_online, customers_id, store_id, UPC_code, price, time)
        values (false,new.customers_id, new.store_id, new.UPC_code, new.price, new.time);
        update product_store
            SET quantity = quantity - 1
            where product_store.store_id = new.store_id and product_store.UPC_code = new.UPC_code;
        return new;
    end;
$$;

alter function alll_orders() owner to postgres;

