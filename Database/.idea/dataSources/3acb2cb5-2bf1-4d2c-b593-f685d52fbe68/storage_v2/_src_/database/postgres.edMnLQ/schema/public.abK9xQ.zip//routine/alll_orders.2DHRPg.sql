create function alll_orders() returns trigger
    language plpgsql
as
$$
BEGIN
        insert into all_orders(order_online, customers_id, store_id, UPC_code, price, time)
        values (false,new.customers_id, new.store_id, new.UPC_code, new.price, new.time);
        return new;
    end;
$$;

alter function alll_orders() owner to postgres;

